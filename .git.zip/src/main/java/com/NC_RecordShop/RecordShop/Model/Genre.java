package com.NC_RecordShop.RecordShop.Model;

public enum Genre {
    ROCK,
    POP,
    JAZZ,
    HIP_HOP,
    CLASSICAL,
    COUNTRY,
    GRIME,
    RAP,
}
