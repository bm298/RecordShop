package com.NC_RecordShop.RecordShop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecordShopApplicationTests {

	@Test
	void contextLoads() {
	}

}
